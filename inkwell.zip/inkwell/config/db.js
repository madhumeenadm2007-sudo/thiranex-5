const mongoose = require('mongoose');

// Cached so serverless hosts (Vercel) reuse the connection between requests.
let cached = global._mongoose;
if (!cached) cached = global._mongoose = { promise: null };

module.exports = async function connectDB() {
  if (!process.env.MONGODB_URI) throw new Error('MONGODB_URI is not set.');
  if (mongoose.connection.readyState === 1) return mongoose.connection;
  if (!cached.promise) {
    cached.promise = mongoose.connect(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 8000 });
  }
  try {
    await cached.promise;
  } catch (err) {
    cached.promise = null;
    throw err;
  }
  return mongoose.connection;
};
