# Inkwell – Blog Platform with Comments

A blogging platform where users register, write posts and discuss them in comments.

**Stack:** HTML/CSS/JavaScript frontend (single page, no framework) · Node.js + Express REST API · MongoDB (Mongoose) · JWT authentication

## Features

- **Accounts:** register and log in. Passwords are hashed with bcrypt and sessions use JWT.
- **Posts:** logged-in users create, edit and delete their own posts. Anyone can read posts, search them and page through them.
- **Comments:** logged-in users comment on any post. A comment can be deleted by its author or by the author of the post. Deleting a post removes its comments.
- **Authorization:** the API checks ownership on the server, so other users cannot edit or delete your posts even by calling the API directly.
- **My posts:** a page listing only your own posts.
- **Responsive and accessible:** works on phones, supports dark mode and keyboard navigation. All user text is inserted as plain text, so posts and comments cannot inject HTML or scripts.

## Structure

```
inkwell/
├── server.js            Express app
├── config/db.js         MongoDB connection
├── middleware/auth.js   JWT authentication
├── models/              User, Post, Comment
├── routes/              auth.js, posts.js, comments.js
├── public/              index.html, css/style.css, js/app.js
└── vercel.json          Optional Vercel config
```

## API

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/auth/register` | public | Create account |
| POST | `/api/auth/login` | public | Log in, returns token |
| GET | `/api/posts?page=1&q=text&author=id` | public | List posts (6 per page) |
| GET | `/api/posts/:id` | public | One post |
| POST | `/api/posts` | user | Create post |
| PUT | `/api/posts/:id` | post author | Edit post |
| DELETE | `/api/posts/:id` | post author | Delete post and its comments |
| GET | `/api/posts/:postId/comments` | public | List comments |
| POST | `/api/posts/:postId/comments` | user | Add comment |
| DELETE | `/api/comments/:id` | comment or post author | Delete comment |

Send the token as `Authorization: Bearer <token>`.

## Run locally

1. Install Node.js 18 or newer and run `npm install`.
2. Copy `.env.example` to `.env` and set:
   - `MONGODB_URI` – a free MongoDB Atlas connection string (or a local MongoDB URL)
   - `JWT_SECRET` – any long random string
3. Run `npm start` and open http://localhost:3000.
4. Create an account, write a post, then register a second account (use a private window) to try commenting.

## Deploy

**Render:** push to GitHub, create a **Web Service**, build command `npm install`, start command `npm start`, add `MONGODB_URI` and `JWT_SECRET`.

**Vercel:** import the GitHub repo, add the same two environment variables and deploy; `vercel.json` is included.

In MongoDB Atlas, allow network access from anywhere (0.0.0.0/0) so the hosted app can connect.

## Submission checklist

- [ ] Live URL works (register, log in, create/edit/delete a post, add a comment)
- [ ] GitHub repository link
- [ ] This project folder / zip
