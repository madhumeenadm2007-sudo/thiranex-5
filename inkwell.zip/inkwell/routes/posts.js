const express = require('express');
const mongoose = require('mongoose');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const auth = require('../middleware/auth');

const router = express.Router();
const PAGE_SIZE = 6;
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function handleError(res, err) {
  if (err.name === 'ValidationError') return res.status(400).json({ error: Object.values(err.errors)[0].message });
  if (err.name === 'CastError') return res.status(400).json({ error: 'Invalid post id.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong.' });
}

// GET /api/posts?page=1&q=search&author=<userId>   (public)
router.get('/', async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const filter = {};
    if (req.query.q) {
      const rx = new RegExp(escapeRegex(String(req.query.q).slice(0, 60)), 'i');
      filter.$or = [{ title: rx }, { content: rx }];
    }
    if (req.query.author) {
      if (!mongoose.isValidObjectId(req.query.author)) return res.status(400).json({ error: 'Invalid author id.' });
      filter.author = req.query.author;
    }

    const [total, docs] = await Promise.all([
      Post.countDocuments(filter),
      Post.find(filter).sort({ createdAt: -1 }).skip((page - 1) * PAGE_SIZE).limit(PAGE_SIZE).populate('author', 'name')
    ]);

    const counts = await Comment.aggregate([
      { $match: { post: { $in: docs.map((d) => d._id) } } },
      { $group: { _id: '$post', n: { $sum: 1 } } }
    ]);
    const countById = new Map(counts.map((c) => [c._id.toString(), c.n]));

    res.json({
      page,
      pages: Math.max(Math.ceil(total / PAGE_SIZE), 1),
      total,
      posts: docs.map((d) => ({
        _id: d._id,
        title: d.title,
        excerpt: d.content.length > 180 ? d.content.slice(0, 180).trim() + '…' : d.content,
        author: d.author ? { _id: d.author._id, name: d.author.name } : { name: 'Deleted user' },
        createdAt: d.createdAt,
        commentCount: countById.get(d._id.toString()) || 0
      }))
    });
  } catch (err) {
    handleError(res, err);
  }
});

// GET /api/posts/:id   (public)
router.get('/:id', async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'name');
    if (!post) return res.status(404).json({ error: 'Post not found.' });
    res.json({
      _id: post._id,
      title: post.title,
      content: post.content,
      author: post.author ? { _id: post.author._id, name: post.author.name } : { name: 'Deleted user' },
      createdAt: post.createdAt,
      updatedAt: post.updatedAt
    });
  } catch (err) {
    handleError(res, err);
  }
});

// POST /api/posts   (logged in)
router.post('/', auth, async (req, res) => {
  try {
    const { title, content } = req.body || {};
    const post = await Post.create({ title, content, author: req.user.id });
    res.status(201).json({ _id: post._id });
  } catch (err) {
    handleError(res, err);
  }
});

// PUT /api/posts/:id   (only the author)
router.put('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found.' });
    if (post.author.toString() !== req.user.id) return res.status(403).json({ error: 'You can only edit your own posts.' });
    const { title, content } = req.body || {};
    if (title !== undefined) post.title = title;
    if (content !== undefined) post.content = content;
    await post.save();
    res.json({ _id: post._id });
  } catch (err) {
    handleError(res, err);
  }
});

// DELETE /api/posts/:id   (only the author; also removes the post's comments)
router.delete('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found.' });
    if (post.author.toString() !== req.user.id) return res.status(403).json({ error: 'You can only delete your own posts.' });
    await Comment.deleteMany({ post: post._id });
    await post.deleteOne();
    res.json({ deleted: true });
  } catch (err) {
    handleError(res, err);
  }
});

module.exports = router;
