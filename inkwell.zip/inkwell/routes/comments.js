const express = require('express');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const auth = require('../middleware/auth');

const router = express.Router();

function handleError(res, err) {
  if (err.name === 'ValidationError') return res.status(400).json({ error: Object.values(err.errors)[0].message });
  if (err.name === 'CastError') return res.status(400).json({ error: 'Invalid id.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong.' });
}

// GET /api/posts/:postId/comments   (public, oldest first)
router.get('/posts/:postId/comments', async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId }).sort({ createdAt: 1 }).populate('author', 'name');
    res.json(
      comments.map((c) => ({
        _id: c._id,
        text: c.text,
        createdAt: c.createdAt,
        author: c.author ? { _id: c.author._id, name: c.author.name } : { name: 'Deleted user' }
      }))
    );
  } catch (err) {
    handleError(res, err);
  }
});

// POST /api/posts/:postId/comments   (logged in)
router.post('/posts/:postId/comments', auth, async (req, res) => {
  try {
    if (!(await Post.exists({ _id: req.params.postId }))) return res.status(404).json({ error: 'Post not found.' });
    const comment = await Comment.create({ post: req.params.postId, author: req.user.id, text: (req.body || {}).text });
    res.status(201).json({ _id: comment._id, text: comment.text, createdAt: comment.createdAt, author: { _id: req.user.id, name: req.user.name } });
  } catch (err) {
    handleError(res, err);
  }
});

// DELETE /api/comments/:id   (the comment's author or the post's author)
router.delete('/comments/:id', auth, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ error: 'Comment not found.' });
    const post = await Post.findById(comment.post);
    const isCommenter = comment.author.toString() === req.user.id;
    const isPostAuthor = post && post.author.toString() === req.user.id;
    if (!isCommenter && !isPostAuthor) return res.status(403).json({ error: 'You cannot delete this comment.' });
    await comment.deleteOne();
    res.json({ deleted: true });
  } catch (err) {
    handleError(res, err);
  }
});

module.exports = router;
