(() => {
  const $ = (id) => document.getElementById(id);
  const view = $('view');

  const load = (key, fallback) => {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
  };
  const state = {
    token: localStorage.getItem('blog_token'),
    user: load('blog_user', null),
    next: null,
    path: '/'
  };

  // ---------- helpers ----------
  const el = (tag, props = {}, children = []) => {
    const node = document.createElement(tag);
    Object.assign(node, props);
    children.forEach((c) => node.append(c));
    return node;
  };
  const fmtDate = (d) => new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });

  let toastTimer;
  function toast(message) {
    const t = $('toast');
    t.textContent = message;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
  }

  async function api(path, options = {}) {
    const res = await fetch('/api' + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(state.token ? { Authorization: 'Bearer ' + state.token } : {})
      }
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && state.token && !path.startsWith('/auth/')) {
      logout(false);
      location.hash = '#/login';
    }
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    return data;
  }

  function setSession({ token, user }) {
    state.token = token;
    state.user = user;
    localStorage.setItem('blog_token', token);
    localStorage.setItem('blog_user', JSON.stringify(user));
  }
  function logout(navigate = true) {
    state.token = null;
    state.user = null;
    localStorage.removeItem('blog_token');
    localStorage.removeItem('blog_user');
    if (navigate) location.hash = '#/';
    renderNav();
  }
  function requireLogin(path) {
    if (state.user) return true;
    state.next = '#' + path;
    location.hash = '#/login';
    return false;
  }

  // ---------- nav + router ----------
  function renderNav() {
    const link = (href, text, path) => {
      const a = el('a', { href, textContent: text, className: state.path === path ? 'active' : '' });
      if (state.path === path) a.setAttribute('aria-current', 'page');
      return a;
    };
    const items = [link('#/', 'Home', '/')];
    if (state.user) {
      items.push(link('#/new', 'Write', '/new'), link('#/mine', 'My posts', '/mine'));
      const out = el('button', { type: 'button', textContent: `Log out (${state.user.name.split(' ')[0]})` });
      out.addEventListener('click', () => logout());
      items.push(out);
    } else {
      items.push(link('#/login', 'Log in', '/login'));
    }
    $('nav').replaceChildren(...items);
  }

  async function route() {
    const [pathPart, queryPart = ''] = (location.hash.replace(/^#/, '') || '/').split('?');
    const parts = pathPart.split('/').filter(Boolean);
    const query = new URLSearchParams(queryPart);
    state.path = '/' + (parts[0] || '');
    renderNav();
    view.replaceChildren(el('p', { className: 'muted', textContent: 'Loading…' }));
    try {
      let node;
      switch (parts[0]) {
        case undefined: node = await listView({ query }); break;
        case 'mine': node = await listView({ query, mine: true }); break;
        case 'post': node = await postView(parts[1]); break;
        case 'new': node = await editorView(null); break;
        case 'edit': node = await editorView(parts[1]); break;
        case 'login': node = await loginView(); break;
        default: node = el('p', { className: 'muted', textContent: 'Page not found.' });
      }
      if (node) view.replaceChildren(node);
    } catch (err) {
      view.replaceChildren(el('p', { className: 'error', textContent: err.message }));
    }
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);

  // ---------- post list (home + my posts) ----------
  async function listView({ query, mine = false }) {
    if (mine && !requireLogin('/mine')) return null;
    const page = Math.max(parseInt(query.get('page'), 10) || 1, 1);
    const q = (query.get('q') || '').trim();
    const params = new URLSearchParams({ page });
    if (q) params.set('q', q);
    if (mine) params.set('author', state.user.id);
    const data = await api('/posts?' + params);

    const base = mine ? '#/mine' : '#/';
    const href = (p) => {
      const sp = new URLSearchParams();
      if (q) sp.set('q', q);
      if (p > 1) sp.set('page', p);
      const s = sp.toString();
      return base + (s ? '?' + s : '');
    };

    const root = el('div');
    const head = el('div', { className: 'page-head' }, [el('h1', { textContent: mine ? 'My posts' : 'Latest posts' })]);
    if (mine) head.append(el('p', {}, [el('a', { className: 'btn', href: '#/new', textContent: 'Write a post' })]));
    root.append(head);

    const input = el('input', { type: 'search', value: q, placeholder: 'Search posts' });
    input.setAttribute('aria-label', 'Search posts');
    const search = el('form', { className: 'search' }, [input, el('button', { className: 'btn', type: 'submit', textContent: 'Search' })]);
    search.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = input.value.trim();
      location.hash = base + (v ? '?q=' + encodeURIComponent(v) : '');
    });
    root.append(search);

    if (!data.posts.length) {
      root.append(el('p', { className: 'muted', textContent: q ? 'No posts match your search.' : mine ? 'You have not written any posts yet.' : 'No posts yet. Log in and write the first one.' }));
      return root;
    }

    root.append(
      el('ul', { className: 'post-list' }, data.posts.map((p) =>
        el('li', { className: 'post-item' }, [
          el('h2', {}, [el('a', { href: '#/post/' + p._id, textContent: p.title })]),
          el('p', { textContent: p.excerpt }),
          el('span', { className: 'meta', textContent: `${p.author.name} · ${fmtDate(p.createdAt)} · ${p.commentCount} comment${p.commentCount === 1 ? '' : 's'}` })
        ])
      ))
    );

    if (data.pages > 1) {
      const prev = el('a', { className: 'btn btn-quiet btn-small', href: href(page - 1), textContent: 'Newer posts' });
      const next = el('a', { className: 'btn btn-quiet btn-small', href: href(page + 1), textContent: 'Older posts' });
      if (page <= 1) prev.style.visibility = 'hidden';
      if (page >= data.pages) next.style.visibility = 'hidden';
      root.append(el('div', { className: 'pager' }, [prev, el('span', { className: 'meta', textContent: `Page ${page} of ${data.pages}` }), next]));
    }
    return root;
  }

  // ---------- single post + comments ----------
  async function postView(id) {
    const [post, comments] = await Promise.all([api('/posts/' + id), api(`/posts/${id}/comments`)]);
    const isAuthor = state.user && post.author._id === state.user.id;

    const root = el('article');
    root.append(
      el('h1', { className: 'post-title', textContent: post.title }),
      el('span', { className: 'meta', textContent: `${post.author.name} · ${fmtDate(post.createdAt)}${post.updatedAt !== post.createdAt && new Date(post.updatedAt) - new Date(post.createdAt) > 60000 ? ' (edited)' : ''}` })
    );

    if (isAuthor) {
      const del = el('button', { className: 'btn btn-danger btn-small', type: 'button', textContent: 'Delete' });
      del.addEventListener('click', async () => {
        if (!confirm('Delete this post and all its comments?')) return;
        try { await api('/posts/' + id, { method: 'DELETE' }); toast('Post deleted.'); location.hash = '#/mine'; } catch (err) { toast(err.message); }
      });
      root.append(el('div', { className: 'btn-row', style: 'margin-top:.8rem' }, [el('a', { className: 'btn btn-quiet btn-small', href: '#/edit/' + id, textContent: 'Edit' }), del]));
    }

    root.append(el('div', { className: 'post-body' }, post.content.split(/\n{2,}/).map((para) => el('p', { textContent: para }))));

    // Comments
    const section = el('section', { className: 'comments' });
    const heading = el('h2');
    const list = el('div');

    function drawComments() {
      heading.textContent = `${comments.length} comment${comments.length === 1 ? '' : 's'}`;
      list.replaceChildren(
        ...comments.map((c) => {
          const head = el('div', { className: 'comment-head' }, [el('strong', { textContent: c.author.name }), el('span', { className: 'meta', textContent: fmtDate(c.createdAt) })]);
          const box = el('div', { className: 'comment' }, [head, el('p', { textContent: c.text })]);
          if (state.user && (c.author._id === state.user.id || isAuthor)) {
            const del = el('button', { className: 'btn btn-quiet btn-small', type: 'button', textContent: 'Delete', style: 'margin-top:.4rem' });
            del.addEventListener('click', async () => {
              try {
                await api('/comments/' + c._id, { method: 'DELETE' });
                comments.splice(comments.findIndex((x) => x._id === c._id), 1);
                drawComments();
              } catch (err) { toast(err.message); }
            });
            box.append(del);
          }
          return box;
        })
      );
    }
    drawComments();
    section.append(heading, list);

    if (state.user) {
      const text = el('textarea', { id: 'commentText', rows: 3, maxLength: 1000 });
      const error = el('p', { className: 'error', role: 'alert' });
      const send = el('button', { className: 'btn', type: 'submit', textContent: 'Post comment' });
      const form = el('form', { className: 'comment-form', noValidate: true }, [el('label', { htmlFor: 'commentText', textContent: 'Add a comment' }), text, error, el('div', { className: 'btn-row', style: 'margin-top:.5rem' }, [send])]);
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!text.value.trim()) { error.textContent = 'Write something before posting.'; return; }
        send.disabled = true;
        error.textContent = '';
        try {
          comments.push(await api(`/posts/${id}/comments`, { method: 'POST', body: JSON.stringify({ text: text.value }) }));
          text.value = '';
          drawComments();
        } catch (err) {
          error.textContent = err.message;
        } finally {
          send.disabled = false;
        }
      });
      section.append(form);
    } else {
      state.next = '#/post/' + id;
      section.append(el('p', { className: 'muted' }, [el('a', { href: '#/login', textContent: 'Log in' }), ' to join the conversation.']));
    }
    root.append(section);
    return root;
  }

  // ---------- create / edit ----------
  async function editorView(id) {
    if (!requireLogin(id ? '/edit/' + id : '/new')) return null;
    let post = { title: '', content: '' };
    if (id) {
      post = await api('/posts/' + id);
      if (post.author._id !== state.user.id) return el('p', { className: 'error', textContent: 'You can only edit your own posts.' });
    }
    const title = el('input', { id: 'pTitle', type: 'text', maxLength: 150, value: post.title, required: true });
    const content = el('textarea', { id: 'pContent', rows: 14, maxLength: 20000, value: post.content, required: true });
    const error = el('p', { className: 'error', role: 'alert' });
    const save = el('button', { className: 'btn', type: 'submit', textContent: id ? 'Save changes' : 'Publish' });
    const form = el('form', { noValidate: true }, [
      el('label', { htmlFor: 'pTitle', textContent: 'Title' }), title,
      el('label', { htmlFor: 'pContent', textContent: 'Post' }), content,
      el('p', { className: 'meta', textContent: 'Leave a blank line between paragraphs.' }),
      error,
      el('div', { className: 'btn-row' }, [save, el('a', { className: 'btn btn-quiet', href: id ? '#/post/' + id : '#/', textContent: 'Cancel' })])
    ]);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!title.value.trim() || !content.value.trim()) { error.textContent = 'Add a title and some content.'; return; }
      save.disabled = true;
      error.textContent = '';
      try {
        const body = JSON.stringify({ title: title.value, content: content.value });
        const result = await api(id ? '/posts/' + id : '/posts', { method: id ? 'PUT' : 'POST', body });
        toast(id ? 'Changes saved.' : 'Post published.');
        location.hash = '#/post/' + result._id;
      } catch (err) {
        error.textContent = err.message;
        save.disabled = false;
      }
    });
    return el('div', {}, [el('div', { className: 'page-head' }, [el('h1', { textContent: id ? 'Edit post' : 'Write a post' })]), form]);
  }

  // ---------- login / register ----------
  async function loginView() {
    if (state.user) { location.hash = '#/'; return null; }
    let mode = 'login';
    const title = el('h1', { textContent: 'Log in' });
    const tabs = el('div', { className: 'tabs', role: 'tablist' });
    const name = el('input', { id: 'a-name', type: 'text', autocomplete: 'name', maxLength: 80 });
    const nameWrap = el('div', { hidden: true }, [el('label', { htmlFor: 'a-name', textContent: 'Name' }), name]);
    const email = el('input', { id: 'a-email', type: 'email', autocomplete: 'email', required: true });
    const password = el('input', { id: 'a-pass', type: 'password', minLength: 6, required: true });
    const error = el('p', { className: 'error', role: 'alert' });
    const submit = el('button', { className: 'btn', type: 'submit', style: 'width:100%;margin-top:1rem' });
    const form = el('form', { className: 'panel', noValidate: true }, [
      nameWrap, el('label', { htmlFor: 'a-email', textContent: 'Email' }), email, el('label', { htmlFor: 'a-pass', textContent: 'Password' }), password, submit, error
    ]);

    function setMode(m) {
      mode = m;
      const reg = m === 'register';
      title.textContent = reg ? 'Create account' : 'Log in';
      nameWrap.hidden = !reg;
      submit.textContent = reg ? 'Create account' : 'Log in';
      password.autocomplete = reg ? 'new-password' : 'current-password';
      error.textContent = '';
      tabs.replaceChildren(
        ...[['login', 'Log in'], ['register', 'Create account']].map(([key, label]) => {
          const b = el('button', { type: 'button', textContent: label });
          b.setAttribute('role', 'tab');
          b.setAttribute('aria-selected', String(mode === key));
          b.addEventListener('click', () => setMode(key));
          return b;
        })
      );
    }
    setMode('login');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      submit.disabled = true;
      error.textContent = '';
      try {
        const body = { email: email.value.trim(), password: password.value };
        if (mode === 'register') body.name = name.value.trim();
        setSession(await api('/auth/' + mode, { method: 'POST', body: JSON.stringify(body) }));
        const dest = state.next || '#/';
        state.next = null;
        location.hash = dest;
      } catch (err) {
        error.textContent = err.message;
      } finally {
        submit.disabled = false;
      }
    });
    return el('div', { className: 'auth-box' }, [title, tabs, form]);
  }

  route();
})();
