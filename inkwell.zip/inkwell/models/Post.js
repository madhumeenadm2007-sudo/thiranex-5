const mongoose = require('mongoose');

const postSchema = new mongoose.Schema(
  {
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: [150, 'Title can be at most 150 characters.'] },
    content: { type: String, required: true, trim: true, maxlength: [20000, 'Post can be at most 20,000 characters.'] }
  },
  { timestamps: true }
);

module.exports = mongoose.models.Post || mongoose.model('Post', postSchema);
