const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Authentication: verifies the Bearer token and loads the user into req.user.
module.exports = async function auth(req, res, next) {
  const header = req.get('Authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Please log in.' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.id);
    if (!user) return res.status(401).json({ error: 'Account not found. Please log in again.' });
    req.user = { id: user._id.toString(), name: user.name };
    next();
  } catch (err) {
    res.status(401).json({ error: 'Your session expired. Please log in again.' });
  }
};
